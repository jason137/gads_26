from flask import Flask
from flask import request
import sentiment_model

app = Flask(__name__)

@app.route("/")
def hello():
    return "Hello World"

@app.route("/sentimentcheck")
def sentiment_check():
    sent = request.args.get('q', '')
    probability = sentiment_model.is_positive(sent)
    if probability > 0.5:
        return "That is positive!"
    else:
        return "That is negative!"

if __name__ == '__main__':
    app.run()
